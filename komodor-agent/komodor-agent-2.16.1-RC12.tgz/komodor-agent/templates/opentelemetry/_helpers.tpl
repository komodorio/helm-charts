{{- define "komodorAgent.openTelemetry.serviceName" -}}
{{- printf "%s-otel-collector" (include "komodorAgent.fullname" .) -}}
{{- end -}}

{{- define "komodorAgent.openTelemetry.serviceFqdn" -}}
{{- printf "http://%s.%s.svc.cluster.local:4318" (include "komodorAgent.openTelemetry.serviceName" .) .Release.Namespace -}}
{{- end -}}

{{- define "opentelemetry.shared.volume.name" -}}
opentelemetry-shared-config
{{- end -}}

{{- define "komodorAgent.opentelemetry.healthEndpointsEnvironment" -}}
- name: WATCHER_HEALTH_ENDPOINT
  value: {{ include "komodorAgent.watcher.healthEndpoint" . | quote }}
- name: ADMISSION_CONTROLLER_ENABLED
  value: {{ .Values.capabilities.admissionController.enabled | quote }}
- name: ADMISSION_CONTROLLER_HEALTH_ENDPOINT
  value: {{ include "komodorAgent.admissionController.healthEndpoint" . | quote }}
{{- end -}}